#include "raylib.h"
#include "Game.h"

int main() {
    InitWindow(1000, 550, "Battleship");
    SetTargetFPS(60);

    Game game;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        game.update();
        game.draw();

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
