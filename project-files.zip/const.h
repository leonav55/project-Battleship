#ifndef CONFIG_H
#define CONFIG_H

#define BOARD_SIZE 5
#define CELL_SIZE 60
#define OFFSET_X 100
#define OFFSET_Y 100


#endif

