#include "Board.h"

Board::Board() {
    shipsLeft = SHIPS;
    for (int i = 0; i < SIZE; i++)
        for (int j = 0; j < SIZE; j++)
            grid[i][j] = '~';
}

void Board::draw(int ox, int oy, bool hideShips) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            Rectangle cell = {
                (float)(ox + j * 60),
                (float)(oy + i * 60),
                60, 60
            };

            Color color = BLUE;

            if (grid[i][j] == 'S' && !hideShips)
                color = GREEN;
            if (grid[i][j] == 'X')
                color = RED;
            if (grid[i][j] == 'O')
                color = LIGHTGRAY;

            DrawRectangleRec(cell, color);
            DrawRectangleLinesEx(cell, 2, BLACK);
        }
    }
}

bool Board::placeShip(int x, int y) {
    if (grid[x][y] == '~') {
        grid[x][y] = 'S';
        return true;
    }
    return false;
}

bool Board::shoot(int x, int y) {
    if (grid[x][y] == 'S') {
        grid[x][y] = 'X';
        shipsLeft--;
        return true;
    }
    if (grid[x][y] == '~') {
        grid[x][y] = 'O';
    }
    return false;
}

bool Board::allShipsSunk() {
    return shipsLeft == 0;
}

char Board::getCell(int x, int y) {
    return grid[x][y];
}
