#include "Player.h"
#include "const.h"
#include "raylib.h"

Player::Player(string name) {
    this->name = name;
}

void Player::placeShips() {
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        Vector2 m = GetMousePosition();
        int x = (m.y - 100) / 60;
        int y = (m.x - 100) / 60;

        if (x >= 0 && x < 5 && y >= 0 && y < 5)
            board.placeShip(x, y);
    }
}

void Player::update(Board& enemyBoard) {
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        Vector2 m = GetMousePosition();
        int x = (m.y - 100) / 60;
        int y = (m.x - 500) / 60;

        if (x >= 0 && x < 5 && y >= 0 && y < 5)
            enemyBoard.shoot(x, y);
    }
}

Board& Player::getBoard() {
    return board;
}

string Player::getName() {
    return name;
}
