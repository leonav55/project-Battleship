#include "AIPlayer.h"
#include <cstdlib>

AIPlayer::AIPlayer(string name) : Player(name) {}

void AIPlayer::placeShips() {
    for (int i = 0; i < 3; i++) {
        int x = rand() % 5;
        int y = rand() % 5;
        board.placeShip(x, y);
    }
}

void AIPlayer::update(Board& enemyBoard) {
    int x = rand() % 5;
    int y = rand() % 5;
    enemyBoard.shoot(x, y);
}
