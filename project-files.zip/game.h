#ifndef GAME_H
#define GAME_H

#include "Player.h"
#include "AIPlayer.h"

enum GameState {
    MENU,
    PLACING_P1,
    PLACING_P2,
    GAME,
    GAME_OVER
};

class Game {
private:
    GameState state;

    Player* player1;
    Player* player2;

    bool isPvAI;
    bool player1Turn;

    float aiTimer;

public:
    Game();

    void update();
    void draw();

    void startPvP();
    void startPvAI();
};

#endif
