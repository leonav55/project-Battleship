#ifndef BOARD_H
#define BOARD_H

#include "const.h"
#include "raylib.h"

class Board {
private:
    static const int SIZE = 5;
    static const int SHIPS = 3;

    char grid[SIZE][SIZE];
    int shipsLeft;

public:
    Board();

    void draw(int offsetX, int offsetY, bool hideShips);
    bool shoot(int x, int y);
    bool placeShip(int x, int y);
    bool allShipsSunk();

    char getCell(int x, int y);
};

#endif
