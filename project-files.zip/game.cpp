#include "Game.h"
#include "raylib.h"
#include "const.h"
#include <cstdlib>




Game::Game() {
    state = MENU;
    player1 = nullptr;
    player2 = nullptr;
    player1Turn = true;
    aiTimer = 0.0f;
}

void Game::startPvP() {
    player1 = new Player("Player 1");
    player2 = new Player("Player 2");
    isPvAI = false;
    state = PLACING_P1;
}

void Game::startPvAI() {
    player1 = new Player("Player");
    player2 = new AIPlayer("AI");
    isPvAI = true;
    state = PLACING_P1;
}

void Game::update() {

    if (state == PLACING_P1) {
        player1->placeShips();

        if (IsKeyPressed(KEY_ENTER)) {
            if (isPvAI) {
                player2->placeShips();
                state = GAME;
            }
            else {
                state = PLACING_P2;
            }
        }
    }

    else if (state == PLACING_P2) {
        player2->placeShips();

        if (IsKeyPressed(KEY_ENTER)) {
            state = GAME;
            player1Turn = true;
        }
    }

    else if (state == GAME) {

        if (player1Turn) {
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                Vector2 m = GetMousePosition();
                int x = (m.y - OFFSET_Y) / CELL_SIZE;
                int y = (m.x - (OFFSET_X + 400)) / CELL_SIZE;

                if (x >= 0 && x < BOARD_SIZE &&
                    y >= 0 && y < BOARD_SIZE) {

                    player2->getBoard().shoot(x, y);
                    player1Turn = false;
                }
            }
        }

        else {
            if (isPvAI) {
                aiTimer += GetFrameTime();
                if (aiTimer > 0.6f) {
                    aiTimer = 0;
                    int x = rand() % BOARD_SIZE;
                    int y = rand() % BOARD_SIZE;
                    player1->getBoard().shoot(x, y);
                    player1Turn = true;
                }
            }
            else {
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                    Vector2 m = GetMousePosition();
                    int x = (m.y - OFFSET_Y) / CELL_SIZE;
                    int y = (m.x - OFFSET_X) / CELL_SIZE;

                    if (x >= 0 && x < BOARD_SIZE &&
                        y >= 0 && y < BOARD_SIZE) {

                        player1->getBoard().shoot(x, y);
                        player1Turn = true;
                    }
                }
            }
        }

        if (player1->getBoard().allShipsSunk() ||
            player2->getBoard().allShipsSunk()) {
            state = GAME_OVER;
        }
    }

    else if (state == GAME_OVER) {
        if (IsKeyPressed(KEY_ENTER)) {
            delete player1;
            delete player2;
            player1 = nullptr;
            player2 = nullptr;
            state = MENU;
        }
    }
}

void Game::draw() {

    if (state == MENU) {
        DrawText("BATTLESHIP", 360, 120, 40, DARKBLUE);
        DrawText("Press 1 - PvP", 420, 220, 20, BLACK);
        DrawText("Press 2 - PvAI", 420, 260, 20, BLACK);

        if (IsKeyPressed(KEY_ONE)) startPvP();
        if (IsKeyPressed(KEY_TWO)) startPvAI();
    }

    else if (state == PLACING_P1) {
        DrawText("Player 1 - Place ships (ENTER)", 300, 30, 20, BLACK);
        player1->getBoard().draw(OFFSET_X, OFFSET_Y, false);
    }

    else if (state == PLACING_P2) {
        DrawText("Player 2 - Place ships (ENTER)", 300, 30, 20, BLACK);
        player2->getBoard().draw(OFFSET_X, OFFSET_Y, false);
    }

    else if (state == GAME) {

        DrawText(player1Turn ? "Player 1 Turn" : "Player 2 Turn",
            420, 30, 20, BLACK);

        if (!isPvAI) {

            if (player1Turn) {
                player1->getBoard().draw(OFFSET_X, OFFSET_Y, true);
                player2->getBoard().draw(OFFSET_X + 400, OFFSET_Y, true);

            }
            else {
                player2->getBoard().draw(OFFSET_X + 400, OFFSET_Y, true);
                player1->getBoard().draw(OFFSET_X, OFFSET_Y, true);

                
            }
        }

        else {
            player1->getBoard().draw(OFFSET_X, OFFSET_Y, false);
            player2->getBoard().draw(OFFSET_X + 400, OFFSET_Y, true);

        }
    }



    else if (state == GAME_OVER) {
        const char* winner =
            player1->getBoard().allShipsSunk()
            ? player2->getName().c_str()
            : player1->getName().c_str();

        DrawText("GAME OVER", 380, 200, 40, RED);
        DrawText(winner, 420, 260, 30, DARKBLUE);
        DrawText("Press ENTER for menu", 330, 320, 20, BLACK);
    }
}
